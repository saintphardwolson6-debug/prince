# ✞𝆺𝅥☆•𝐏𝐫!𝐧𝐜𝐞$✞𝆺𝅥☆👑!¡! - WhatsApp Bot

A feature-rich WhatsApp bot built with Baileys.

## Owner
- **Bot Name:** ✞𝆺𝅥☆•𝐏𝐫!𝐧𝐜𝐞$✞𝆺𝅥☆👑!¡!
- **Owner:** ✞𝆺𝅥☆•𝐏𝐫!𝐧𝐜𝐞$✞𝆺𝅥☆👑!¡!
- **Owner Number:** +243985681033
- **Version:** 1.0.0
- **Prefix:** .

## Links
- 📢 **WhatsApp Channel:** https://whatsapp.com/channel/0029VbCzf9AJkK7GCvCFOv3s
- 👥 **Auto Join Group:** https://chat.whatsapp.com/JOKHgX7HBGMLeR0OwKlBQ6?s=cl&p=a&mlu=1
- 🐙 **GitHub:** https://github.com/saintphardwolson6-debug/prince

## Setup

1. Clone the repository
2. Run `npm install`
3. Add your session credentials to the `session/` folder
4. Configure your number in `settings.js`
5. Run `npm start`

## Features
- Group Management
- Anti-link & Anti-bad-word Protection
- Fun Commands
- AI Commands
- Sticker & Media Tools
- Downloader Commands
- And much more!
