const settings = {
  packname: '✞𝆺𝅥☆•𝐏𝐫!𝐧𝐜𝐞$✞𝆺𝅥☆👑!¡!',
  author: '✞𝆺𝅥☆•𝐏𝐫!𝐧𝐜𝐞$✞𝆺𝅥☆👑!¡!',
  botName: "✞𝆺𝅥☆•𝐏𝐫!𝐧𝐜𝐞$✞𝆺𝅥☆👑!¡!",
  botOwner: '✞𝆺𝅥☆•𝐏𝐫!𝐧𝐜𝐞$✞𝆺𝅥☆👑!¡!', // Your name
  ownerNumber: '243985681033', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "1.0.0",
  updateZipUrl: "https://github.com/saintphardwolson6-debug/prince/archive/refs/heads/main.zip",
};

module.exports = settings;
