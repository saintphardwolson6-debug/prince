const isAdmin = require('../lib/isAdmin');
const { channelInfo } = require('../lib/messageConfig');

async function kickallCommand(sock, chatId, senderId, message) {
    // Only works in groups
    if (!chatId.endsWith('@g.us')) {
        await sock.sendMessage(chatId, { text: 'This command can only be used in groups.', ...channelInfo }, { quoted: message });
        return;
    }

    const isOwner = message.key.fromMe;

    if (!isOwner) {
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

        if (!isBotAdmin) {
            await sock.sendMessage(chatId, { text: 'Please make the bot an admin first.', ...channelInfo }, { quoted: message });
            return;
        }

        if (!isSenderAdmin) {
            await sock.sendMessage(chatId, { text: 'Only group admins can use .kickall.', ...channelInfo }, { quoted: message });
            return;
        }
    }

    try {
        const metadata = await sock.groupMetadata(chatId);
        const participants = metadata.participants || [];

        // Get bot JID
        const botId = sock.user?.id || '';
        const botPhoneNumber = botId.includes(':') ? botId.split(':')[0] : (botId.includes('@') ? botId.split('@')[0] : botId);
        const botJid = botPhoneNumber + '@s.whatsapp.net';
        const botLid = sock.user?.lid || '';
        const botLidNumeric = botLid.includes(':') ? botLid.split(':')[0] : (botLid.includes('@') ? botLid.split('@')[0] : botLid);

        // Build list of non-admin, non-bot members to kick
        const toKick = participants.filter(p => {
            // Skip admins/superadmins
            if (p.admin === 'admin' || p.admin === 'superadmin') return false;

            const pId = p.id || '';
            const pPhoneNumber = pId.includes(':') ? pId.split(':')[0] : (pId.includes('@') ? pId.split('@')[0] : pId);
            const pLid = p.lid || '';
            const pLidNumeric = pLid.includes(':') ? pLid.split(':')[0] : (pLid.includes('@') ? pLid.split('@')[0] : pLid);

            // Skip the bot itself
            if (
                pId === botId ||
                pId === botJid ||
                pPhoneNumber === botPhoneNumber ||
                (botLidNumeric && pLidNumeric && pLidNumeric === botLidNumeric)
            ) return false;

            return true;
        }).map(p => p.id);

        if (toKick.length === 0) {
            await sock.sendMessage(chatId, { text: 'No non-admin members to kick.', ...channelInfo }, { quoted: message });
            return;
        }

        await sock.sendMessage(chatId, {
            text: `⚠️ Kicking *${toKick.length}* member(s) from the group...`,
            ...channelInfo
        }, { quoted: message });

        // Kick in batches of 5 to avoid rate limits
        const batchSize = 5;
        for (let i = 0; i < toKick.length; i += batchSize) {
            const batch = toKick.slice(i, i + batchSize);
            await sock.groupParticipantsUpdate(chatId, batch, 'remove');
            // Small delay between batches
            if (i + batchSize < toKick.length) {
                await new Promise(r => setTimeout(r, 1500));
            }
        }

        await sock.sendMessage(chatId, {
            text: `✅ Successfully kicked *${toKick.length}* member(s) from the group.`,
            ...channelInfo
        });

    } catch (error) {
        console.error('Error in kickall command:', error);
        await sock.sendMessage(chatId, { text: 'Failed to kick all members. Make sure the bot is an admin.', ...channelInfo }, { quoted: message });
    }
}

module.exports = kickallCommand;
